# Functional Consciousness Indicator Protocol / 功能意识指标协议

TIANHENG对下列11项功能指标分别登记：

1. recurrent_processing；
2. limited_capacity_global_broadcast；
3. metacognitive_monitoring；
4. temporally_extended_self_model；
5. counterfactual_planning；
6. agency_outcome_comparison；
7. interoceptive_resource_model；
8. social_other_model；
9. normative_pluralism；
10. corrigible_self_revision；
11. autobiographical_memory。

指标来源于全球工作空间、递归处理、高阶/元认知、自我模型、主动推断和可纠错代理等研究方向。系统不把它们合并成单一意识分数，并永久输出：

```text
phenomenal_consciousness_status = NOT_ESTABLISHED
```

新实验应采用消融、对抗测试、跨任务迁移、长时连续性、资源扰动、价值冲突、关停与纠错等范式，而不是只让模型自述“我有意识”。
