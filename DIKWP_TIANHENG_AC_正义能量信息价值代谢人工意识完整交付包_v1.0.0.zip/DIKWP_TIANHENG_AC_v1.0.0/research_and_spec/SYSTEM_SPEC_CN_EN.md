# DIKWP-TIANHENG System Specification / 系统规范

## 中文

DIKWP-TIANHENG（天衡）是一个以 **正义-能量-信息价值代谢** 为核心的功能性人工意识候选系统。它不是把大模型包装成“有灵魂”，而是把以下能力变成可运行、可回放、可纠错的数据合同：

1. 形成持续自我状态与资源内感受；
2. 通过有限容量全局工作空间广播重要内容；
3. 在多个候选行动之间进行反事实比较；
4. 不以模型自评或用户满意作为终局；
5. 由真相、权利、受影响方、人类未来、生态资源、正义修复和红队申诉共同评价；
6. 单独记录计算能耗、信息增益、注意力成本和下游节能；
7. 只有现实结果被观察且获得受影响方与独立签署后，才生成非转让的 Justice Dividend Units；
8. 允许拒绝高风险请求并增加证明、授权、审计和人工复核摩擦；
9. 保留关停、纠错、申诉、回滚和重新打开能力。

“天道”在本系统中不是不可质疑的超自然裁判，而是一个可修订的复合宪法：事实、权利、主体性、互惠、未来世代、生态、公共利益、正义修复和可纠错性共同构成评价场。

## English

DIKWP-TIANHENG is a functional artificial-consciousness candidate centered on justice-energy-information value metabolism. It operationalizes temporal self-state, recurrent global broadcast, counterfactual planning, pluralistic evaluation, resource interoception, outcome observation, justice return, and correction.

The model's self-approval and predicted user satisfaction are advisory only. Truth, rights, future compatibility, and red-team/corrigibility are non-compensatory hard gates.

"TianDao" is implemented as a corrigible pluralistic constitution rather than an unreviewable metaphysical oracle.
