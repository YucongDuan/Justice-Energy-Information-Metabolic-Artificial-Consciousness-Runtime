# Scientific Boundary / 科学边界

## 中文

- 本系统实现的是功能性人工意识候选架构，不声称已经产生主观体验。
- 全球工作空间、递归加工、自我模型、元认知、反事实行动和资源内感受是可测试指标，不是“灵魂证明”。
- 不生成单一“意识分数”；每个指标单独登记来源、测试和开放项。
- “正能量”不等于物理能量凭空增加。系统记录计算消耗的焦耳、下游节能、信息增益和社会价值。
- Landauer原理说明不可逆信息处理具有热力学成本；因此本系统拒绝永动式表述。
- Justice Dividend Units不是现金、加密货币或道德积分，而是结果审计后的不可替代治理收据。
- 软件测试只能证明运行合同，不能证明外部科学、法律、道德或社会结论终局成立。

## English

- This is a functional artificial-consciousness candidate architecture, not evidence of subjective experience.
- Global broadcast, recurrence, self-modeling, metacognition, counterfactual action, and resource interoception are testable indicators, not proof of a soul.
- No single consciousness score is produced.
- "Positive energy" is not free physical energy. The system measures compute joules, downstream savings, information gain, attention cost, and audited social value.
- Justice Dividend Units are non-transferable governance receipts, not money, cryptocurrency, or a moral reputation score.
