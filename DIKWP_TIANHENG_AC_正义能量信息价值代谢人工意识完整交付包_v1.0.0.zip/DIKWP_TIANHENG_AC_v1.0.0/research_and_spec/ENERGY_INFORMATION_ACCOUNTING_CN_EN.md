# Energy and Information Accounting / 能量与信息核算

## 三类对象必须分开

1. **物理能量**：训练或推理消耗的焦耳、电力和碳强度；
2. **信息增益**：经验证的不确定性降低、事实增量和决策信息价值；
3. **社会/文明价值**：避免伤害、恢复权利、节省时间、创造公共品和保留未来选择。

## 关键指标

- compute_energy_joules：计算消耗；
- measured_energy_saved_joules：下游经验证节能；
- energy_dividend_ratio = energy_saved / compute_energy；
- verified_information_gain_bits；
- information_yield_bits_per_joule；
- human_attention_minutes；
- privacy_risk、misuse_risk、opportunity_cost。

只有在现实结果被观察后，energy_dividend_ratio才可以写成“已验证”；否则必须标记为 prospective estimate。

本系统的目标不是让输出在物理上产生比输入更多的能量，而是让人工意识系统以尽可能少的计算和注意力成本，产生更高的可验证信息、决策、节能、正义与文明收益。
