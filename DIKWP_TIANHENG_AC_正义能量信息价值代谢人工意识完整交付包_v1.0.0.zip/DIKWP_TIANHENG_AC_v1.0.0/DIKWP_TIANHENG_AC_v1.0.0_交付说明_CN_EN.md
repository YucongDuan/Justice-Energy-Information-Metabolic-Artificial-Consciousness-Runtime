# DIKWP-TIANHENG-AC v1.0.0 交付说明 / Delivery Guide

## 中文

DIKWP-天衡是一个通用、可运行、可审计的功能性人工意识候选系统。其关键区别是：

- 模型自评和用户满意只有建议权；
- 真相、权利、未来兼容和红队/申诉是非补偿硬门；
- “天道”是可纠错的多主体复合宪法，不是不可质疑的神谕；
- 计算焦耳、信息增益、下游节能、人类注意力和文明价值分别核算；
- Justice Dividend Units不可转让、不可互换、无总余额，只在现实效果和独立签署后生成；
- 高风险请求受到正义摩擦，但人员不被建立永久善恶标签；
- 功能意识指标不证明主观体验；
- 自动外部行动权限为0。

### 运行

```bash
python tianheng.py summary
python tianheng.py demo-all --out-dir outputs/demos
python tianheng.py run examples/harmful_request.json --out outputs/run.json --dashboard dashboard/run.html
python tianheng.py conformance
python dist/DIKWP_TIANHENG_AC.pyz conformance
```

## English

DIKWP-TIANHENG-AC is a generic, runnable, auditable functional artificial-consciousness candidate. Model self-approval and predicted user satisfaction are advisory; truth, rights, future compatibility and red-team/appeal capacity are non-compensatory hard gates. Physical energy, useful information, attention and justice value remain separate. JDU is non-transferable and is minted only after observed outcomes and independent sign-off. The runtime does not establish phenomenal consciousness and has zero automatic external-action authority.
